/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_12021;
/**
 *Esta clase hereda de la clase Vehiculo y tiene funcionalidad util para el uso del programa
 * @author Emmanuel Herrera y Yoni Custoio
 * @version 1.0.0
 **/


public enum EnumVehiculo {
    
    AUTOMOVIL, CAMION, MOTOCICLETA;
    
}
